import numpy as np
from PIL import Image 
import random
import os

def enc_dec_img(imgpath, operation, key_seed):
    random.seed(key_seed)

    img = Image.open(imgpath)
    img.load()
    full_img_arr = np.asarray(img,dtype="uint8").copy()

    r,c = full_img_arr.shape
    full_img_arr = full_img_arr.flatten()
    length = len(full_img_arr)
    for i in range(length):
        print(f"{int((i/length)*100)}% Done")
        full_img_arr[i] = full_img_arr[i] ^ random.randint(0,255)
    os.system("cls")

    full_img_arr = full_img_arr.reshape((r,c))
    new_image = Image.fromarray(full_img_arr)
    if operation == "E":
        print("Done!! Your encrypted image is saved as encrypted.png")
        new_image.save("encrypted.png")
    elif operation == "D":
        print("Done!! Your decrypted image is saved as decrypted.png")
        new_image.save("decrypted.png")


if __name__ == "__main__":
    print("Welcome to my Image Encryption/Decryption application!\nPlease Note that this application can only be used to encrypt/decrypt Gray Scale Images.\n"+'-'*60)
    path = input("Enter path for a photo to encrypt/decrypt: ")
    op = input("1- [E]ncrypt\n2- [D]ecrypt\n")
    key = int(input("Enter key: "))
    enc_dec_img(imgpath=path, operation=op, key_seed=key)
